package forRunning;

import java.awt.EventQueue;

import design.MainFrame;
import extra.AliveConnection;
import extra.PhotoSender;

public class ClientMain {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AliveConnection.alivePort = 55556;
					PhotoSender.photoSendingPort = 55557;
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
