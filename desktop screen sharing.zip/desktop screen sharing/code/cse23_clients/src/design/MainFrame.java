package design;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import extra.AliveConnection;
import extra.PhotoSender;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tIP;
	private JTextField tPort;
	private JTextField tNameField;

	private JLabel connectionStatus = null;

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 467, 372);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("SET IP ADDRESS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(10, 51, 431, 31);
		contentPane.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 82, 431, 31);
		contentPane.add(panel_1);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));

		tIP = new JTextField();
		tIP.setFont(new Font("Tahoma", Font.BOLD, 18));
		tIP.setText("192.168.137.1");
		panel_1.add(tIP);
		tIP.setColumns(10);

		JButton btnNewButton_1 = new JButton("CLEAR");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tIP.setText("");
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel_1.add(btnNewButton_1);

		JLabel lblSetPortNumber = new JLabel("SET PORT NUMBER");
		lblSetPortNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblSetPortNumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSetPortNumber.setBounds(10, 125, 431, 31);
		contentPane.add(lblSetPortNumber);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 157, 431, 31);
		contentPane.add(panel_2);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.X_AXIS));

		tPort = new JTextField();
		tPort.setFont(new Font("Tahoma", Font.BOLD, 18));
		tPort.setText("55555");
		tPort.setColumns(10);
		panel_2.add(tPort);

		JButton button_1 = new JButton("CLEAR");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tPort.setText("");
			}
		});
		button_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panel_2.add(button_1);

		JButton btnDisconnect = new JButton("Disconnect");
		btnDisconnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AliveConnection.setAlive = false;
				PhotoSender.photoSenderAliveStatus = false;
			}
		});
		btnDisconnect.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDisconnect.setBounds(229, 285, 212, 37);
		contentPane.add(btnDisconnect);

		JButton btnConnect = new JButton("Connect");
		btnConnect.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (tNameField.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "Enter Your Name First!!!");
					return;
				}
				if (tIP.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "Enter IP address first!!!");
					return;
				}
				if (tPort.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "Enter port number first!!!");
					return;
				}
				try {
					Socket socket = new Socket(tIP.getText(), Integer.parseInt(tPort.getText()));
					ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
					out.flush();
					out.writeObject(tNameField.getText());
					socket.close();
					new Thread(new AliveConnection()).start();
					new Thread(new PhotoSender()).start();
					connectionStatus.setText("you are Connected");
				} catch (Exception ex) {
					ex.printStackTrace();
					connectionStatus.setText("you are Not Connected");
				}
			}
		});
		btnConnect.setBounds(10, 285, 212, 37);
		contentPane.add(btnConnect);

		connectionStatus = new JLabel("YOU ARE NOT CONNTECTED");
		connectionStatus.setFont(new Font("Tahoma", Font.BOLD, 15));
		connectionStatus.setHorizontalAlignment(SwingConstants.RIGHT);
		connectionStatus.setBounds(10, 11, 431, 19);
		contentPane.add(connectionStatus);

		JLabel lblSetYourName = new JLabel("SET YOUR NAME");
		lblSetYourName.setHorizontalAlignment(SwingConstants.CENTER);
		lblSetYourName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSetYourName.setBounds(10, 199, 431, 31);
		contentPane.add(lblSetYourName);

		tNameField = new JTextField();
		tNameField.setFont(new Font("Tahoma", Font.BOLD, 18));
		tNameField.setText("GOBINDA");
		tNameField.setColumns(10);
		tNameField.setBounds(10, 231, 342, 31);
		contentPane.add(tNameField);

		JButton button = new JButton("CLEAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tNameField.setText("");
			}
		});
		button.setFont(new Font("Tahoma", Font.PLAIN, 19));
		button.setBounds(352, 231, 89, 31);
		contentPane.add(button);

		setLocationRelativeTo(null);
	}
}
