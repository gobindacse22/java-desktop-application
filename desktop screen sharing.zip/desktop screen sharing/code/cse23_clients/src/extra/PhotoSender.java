package extra;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.imageio.ImageIO;

public class PhotoSender implements Runnable {

	public static int photoSendingPort = 55557;
	public static boolean photoSenderAliveStatus = true;

	public PhotoSender() {

	}

	@Override
	public void run() {
		while (photoSenderAliveStatus) {
			try {
				ServerSocket serverSocket = new ServerSocket(photoSendingPort);
				Socket sock = serverSocket.accept();
				ObjectOutputStream out = new ObjectOutputStream(sock.getOutputStream());
				out.flush();
				BufferedImage screenshot = new Robot()
						.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
				ImageIO.write(screenshot, "jpg", out);

				sock.close();
				serverSocket.close();
			} catch (Exception e) {
			}
		}
	}

	public static void setPhotoSenderAliveStatus(boolean photoSenderAliveStatus) {
		PhotoSender.photoSenderAliveStatus = photoSenderAliveStatus;
	}

}
