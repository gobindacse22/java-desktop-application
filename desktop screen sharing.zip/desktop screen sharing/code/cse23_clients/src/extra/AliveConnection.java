package extra;

import java.net.ServerSocket;
import java.net.Socket;

public class AliveConnection implements Runnable {

	public static int alivePort = 55556;
	public static boolean setAlive = true;

	public AliveConnection() {

	}

	@Override
	public void run() {

		try {
			ServerSocket serverSocket = new ServerSocket(alivePort);
			while (setAlive) {
				Socket sock = serverSocket.accept();
				sock.close();
			}
			serverSocket.close();
		} catch (Exception e) {
		}
	}

	public void setAlive(boolean alive) {
		setAlive = alive;
	}

}
