package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.BoxLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Formatter;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.omg.CORBA.PUBLIC_MEMBER;

public class Main extends JFrame implements MouseListener, MouseMotionListener {

	private JPanel contentPane;
	public static JFrame mainFrame;
	public static Board board;

	public static Vector<People> guys = new Vector<People>();

	public static String fileLocationString = new String(
			"resource/info.txt");

	public static void main(String[] args) {

		ScanAllFile();
		CreateFrame();

	}

	private static void ScanAllFile() {
		// TODO Auto-generated method stub

		File f = new File(fileLocationString);
		Scanner scanner = null;
		try {
			scanner = new Scanner(f);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
		}

		while (scanner.hasNextLine()) {

			String ss = scanner.nextLine();

			int a = Integer.parseInt(ss.substring(0, 6));
			String nString = ss.substring(7, 22).trim();
			int b = Integer.parseInt(ss.substring(23, 29));

			People people = new People(nString, b, a);
			guys.add(people);

		}

		//System.out.println("ok");
	}

	public static void saveAllPeople() {

		Formatter f = null;
		try {
			f = new Formatter(new File(fileLocationString));
		} catch (Exception e) {
			// TODO: handle exception
		}

		int len = guys.size();
		for (int i = 0; i < len; i++) {
			f.format("%s\n", guys.get(i).getAll());
		}

		f.close();
	}

	private static void CreateFrame() {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainFrame = new Main();
					mainFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {

		addMouseListener(this);
		addMouseMotionListener(this);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 580);
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(153, 255, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("ACCOUNT");
		lblNewLabel.setBackground(new Color(153, 255, 255));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(0, 11, 414, 38);
		contentPane.add(lblNewLabel);

		board = new Board();
		board.setBounds(10, 103, 394, 440);
		contentPane.add(board);
		board.setLayout(new BorderLayout(0, 0));

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(10, 60, 394, 32);
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 5, 0, 0));

		JButton btnNewButton = new JButton("NEW");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Add frame = new Add();
				frame.setVisible(true);
				mainFrame.setVisible(false);

			}
		});
		panel_1.add(btnNewButton);

		JButton btnDeleteAccount = new JButton("DELETE");
		btnDeleteAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int len = guys.size();
				Board.selected_option += Board.extraForPage;
				if (Board.selected_option != -1 && len >= Board.selected_option) {
					guys.remove(Board.selected_option - 1);
					saveAllPeople();
					Board.selected = false;
					board.repaint();
				}

			}
		});
		panel_1.add(btnDeleteAccount);

		JButton btnEdit = new JButton("EDIT");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				EditFrame frame = new EditFrame();
				Main.mainFrame.setVisible(false);

			}
		});
		panel_1.add(btnEdit);

		JButton btnNewButton_1 = new JButton("SHOW");
		panel_1.add(btnNewButton_1);

		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				System.exit(-1);
			}
		});
		panel_1.add(btnExit);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				board.repaint();

			}
		});
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		// System.out.println("oskjdflsakdf");
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
}
