package all;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JPanel;

public class Board extends JPanel implements MouseListener,
		MouseMotionListener, MouseWheelListener {

	public static int selected_y, selected_option, extraForPage = 0;
	public static boolean selected;

	public Board() {
		super();

		selected_option = -1;

		addMouseListener(this);
		addMouseMotionListener(this);
		addMouseWheelListener(this);

	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (selected) {
			drawSelected(g);
		}

		drawAllAccount(g);

	}

	private void drawSelected(Graphics g) {
		// TODO Auto-generated method stub

		g.setColor(Color.RED);
		g.fillRect(4, selected_y, 385, 25);

	}

	private void drawAllAccount(Graphics g) {
		// TODO Auto-generated method stub

		g.setColor(Color.BLACK);

		int y = 25;
		int len = Main.guys.size();

		g.setFont(new Font("Arial", Font.PLAIN, 18));
		g.drawRect(4, 5, 385, 428);

		FontMetrics ff = g.getFontMetrics();

		String s = new String("Number");
		g.drawString(s, 48 - ff.stringWidth(s) / 2, y);

		s = new String("Name");
		g.drawString(s, 190 - ff.stringWidth(s) / 2, y);

		s = new String("Taka");
		g.drawString(s, 340 - ff.stringWidth(s) / 2, y);

		g.drawLine(4, y + 8, 389, y + 8);

		int j = 0;
		for (int i = extraForPage; i < len; i++) {
			y += 25;
			String ss = String.valueOf(Main.guys.get(i).getAccountNumber());
			g.drawString(ss, 48 - ff.stringWidth(ss) / 2, y);

			ss = Main.guys.get(i).getName();
			g.drawString(ss, 190 - ff.stringWidth(ss) / 2, y);

			ss = String.valueOf(Main.guys.get(i).getTk());
			g.drawString(ss, 340 - ff.stringWidth(ss) / 2, y);

			g.drawLine(4, y + 8, 389, y + 8);
			j++;
			if (j > 15) {
				break;
			}
		}
		// System.out.println("ys:" + (y + 8));
		g.drawLine(90, 5, 90, y + 8);
		g.drawLine(290, 5, 290, y + 8);

	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

		
		if(e.getButton()==3){
			selected=false;
			repaint();
			return;
		}
		
		
		Point point = e.getPoint();

		if (point.x < 4 || 389 < point.x || point.y < 33) {
			return;
		}

		int y = (point.y - 8) / 25;

	

		// System.out.println(selected_option);

		if (y > 16) {
			return;
		}

		if (y + extraForPage > Main.guys.size()) {
			return;
		}
		selected_option = y;
		y *= 25;

		selected_y = y + 8;
		selected = true;
		repaint();

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		// TODO Auto-generated method stub

		int len = Main.guys.size();
		if (len < 16)
			return;

		if (e.getWheelRotation() == 1) {
			if (extraForPage > 0) {
				extraForPage--;
			}
		} else {
			if (extraForPage + 16 < len)
				extraForPage++;
		}

		// System.out.println("   " + extraForPage);

		repaint();

	}

}
