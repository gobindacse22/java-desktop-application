package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Add extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private static JLabel info;

	public Add() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 580);
		setLocationRelativeTo(null);
		setResizable(false);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("ADD ACCOUNT");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(0, 11, 414, 42);
		contentPane.add(lblNewLabel);

		JLabel lblAccountId = new JLabel("ACCOUNT ID:");
		lblAccountId.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAccountId.setBounds(67, 156, 301, 25);
		contentPane.add(lblAccountId);

		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField.setBounds(67, 184, 301, 32);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblAccountName = new JLabel("ACCOUNT NAME:");
		lblAccountName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAccountName.setBounds(67, 227, 301, 25);
		contentPane.add(lblAccountName);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_1.setColumns(10);
		textField_1.setBounds(67, 255, 301, 32);
		contentPane.add(textField_1);

		JLabel lblAccountBalance = new JLabel("ACCOUNT BALANCE:");
		lblAccountBalance.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblAccountBalance.setBounds(67, 298, 301, 25);
		contentPane.add(lblAccountBalance);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_2.setColumns(10);
		textField_2.setBounds(67, 326, 301, 32);
		contentPane.add(textField_2);

		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String s1 = textField.getText();
				String s2 = textField_1.getText();
				String s3 = textField_2.getText();

				if (s1.equals("")) {
					info.setText("Empty Account Number!");
					return;
				}
				if (s2.equals("")) {
					info.setText("Empty Account Name:");
					return;
				}

				if (s1.length() > 6) {
					info.setText("Account Number Will be less than 7 digit");
					return;
				}
				if (s2.length() > 15) {
					info.setText("Account Name Will be less than 16 digit");
					return;
				}

				int acc, tk = 0;

				try {
					acc = Integer.parseInt(s1);
				} catch (Exception e) {
					// TODO: handle exception
					info.setText("Please Enter a Valid Account Number.");
					return;
				}
				try {
					if (!s3.equals(""))
						tk = Integer.parseInt(s3);
				} catch (Exception e) {
					// TODO: handle exception
					info.setText("Please Enter a Valid Amount.");
					return;
				}

				if (Math.abs(tk) > 99999) {
					info.setText("Ammount Should be -1000000<x<1000000");
					return;
				}

				People p = new People(s2, tk, acc);
				Main.guys.add(p);

				Main.saveAllPeople();

				Main.mainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSave.setBounds(271, 387, 97, 32);
		contentPane.add(btnSave);

		JButton btnCancle = new JButton("CANCLE");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main.mainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnCancle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCancle.setBounds(177, 387, 89, 32);
		contentPane.add(btnCancle);

		JLabel lblInsertAllThe = new JLabel("INSERT ALL THE INFORMATION");
		lblInsertAllThe.setHorizontalAlignment(SwingConstants.CENTER);
		lblInsertAllThe.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblInsertAllThe.setBounds(0, 64, 414, 42);
		contentPane.add(lblInsertAllThe);

		info = new JLabel("");
		info.setHorizontalAlignment(SwingConstants.CENTER);
		info.setFont(new Font("Tahoma", Font.PLAIN, 17));
		info.setBounds(0, 516, 414, 25);
		contentPane.add(info);
	}
}
