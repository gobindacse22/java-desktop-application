package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	public static JLabel info;

	public EditFrame() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 580);
		setVisible(true);
		setLocationRelativeTo(null);
		setResizable(false);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Edit Account");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(5, 5, 414, 30);
		contentPane.add(lblNewLabel);

		JLabel label = new JLabel("Account Number:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 20));
		label.setBounds(87, 127, 200, 25);
		contentPane.add(label);

		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField.setColumns(10);
		textField.setBounds(87, 154, 221, 30);
		contentPane.add(textField);

		if (Board.selected) {
			textField.setText(String.valueOf(Main.guys.get(
					Board.extraForPage + Board.selected_option-1)
					.getAccountNumber()));
		}

		JLabel label_1 = new JLabel("Deposit Money:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		label_1.setBounds(87, 195, 200, 25);
		contentPane.add(label_1);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_1.setColumns(10);
		textField_1.setBounds(87, 222, 221, 30);
		contentPane.add(textField_1);

		JLabel label_2 = new JLabel("WithDral Money");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		label_2.setBounds(87, 263, 200, 25);
		contentPane.add(label_2);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textField_2.setColumns(10);
		textField_2.setBounds(87, 290, 221, 30);
		contentPane.add(textField_2);

		JButton btnNewButton = new JButton("Ok");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int accNumber, withDral, deposit;
				try {
					accNumber = Integer.parseInt(textField.getText());
				} catch (Exception e2) {
					// TODO: handle exception
					info.setText("Please Enter a Valid Account Number");
					return;
				}

				try {
					if (!textField_1.getText().equals(""))
						withDral = Integer.parseInt(textField_1.getText());
					else
						withDral = 0;
				} catch (Exception e2) {
					// TODO: handle exception
					info.setText("Please Enter a Valid WithDral Amount");
					return;
				}

				try {
					if (!textField_2.getText().equals(""))
						deposit = Integer.parseInt(textField_2.getText());
					else
						deposit = 0;
				} catch (Exception e2) {
					// TODO: handle exception
					info.setText("Please Enter a Valid Deposit Amount");
					return;
				}

				int len = Main.guys.size();

				boolean ans = false;
				for (int i = 0; i < len; i++) {
					if (Main.guys.get(i).getAccountNumber() == accNumber) {
						ans = true;
						Main.guys.get(i).depositTk(deposit);
						Main.guys.get(i).withDralTk(withDral);
						break;
					}
				}

				if (ans == false) {
					info.setText("Account Number Not Fount!");
					return;
				} else {
					Main.saveAllPeople();
				}

				info.setText("Transection SuccessFul.");

				Main.mainFrame.setVisible(true);
				setVisible(false);

			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(239, 349, 69, 30);
		contentPane.add(btnNewButton);

		JButton btnCancle = new JButton("Cancle");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Main.mainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnCancle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCancle.setBounds(143, 349, 91, 30);
		contentPane.add(btnCancle);

		info = new JLabel("");
		info.setHorizontalAlignment(SwingConstants.CENTER);
		info.setFont(new Font("Tahoma", Font.PLAIN, 18));
		info.setBounds(5, 532, 414, 30);
		contentPane.add(info);

	}

}
