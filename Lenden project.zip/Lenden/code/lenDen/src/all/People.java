package all;

public class People {

	private String Name;
	private int Tk;
	private int AccountNumber;

	public String getAll() {

		String string = new String("");
		String string2 = new String("");
		String string3 = new String("");

		string = String.valueOf(AccountNumber);
		for (int i = string.length(); i < 6; i++) {
			string = "0" + string;
		}

		string2 = new String(Name);
		for (int i = string2.length(); i < 15; i++) {
			string2 = string2 + " ";
		}

		byte n = 6;
		if (Tk < 0) {
			n = 5;
			Tk *= -1;
		}
		string3 = String.valueOf(Tk);
		for (int i = string3.length(); i < n; i++) {
			string3 = "0" + string3;
		}
		if (n == 5) {
			string3 = "-" + string3;
			Tk *= -1;
		}

		return string + " " + string2 + " " + string3;
	}

	public People(String name, int tk, int accountNumber) {
		Name = name;
		Tk = tk;
		AccountNumber = accountNumber;
	}

	public String getName() {
		return Name;
	}

	public int getTk() {
		return Tk;
	}

	public void depositTk(int x) {
		Tk += x;
	}

	public void withDralTk(int y) {
		Tk -= y;
	}

	public int getAccountNumber() {
		return AccountNumber;
	}

}
